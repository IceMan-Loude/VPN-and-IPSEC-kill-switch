import subprocess
import time
import os
import re
from threading import Thread

# Configuration
VPN_INTERFACE = "tun0"  # VPN interface name (e.g., tun0 for OpenVPN)
NETWORK_INTERFACE = "eth0"  # Default network interface
VPN_CLI_COMMAND = "openvpn --config /path/to/vpn-config.ovpn"  # Example VPN command

# Connect to the VPN
def connect_vpn():
    print("Connecting to VPN...")
    process = subprocess.Popen(VPN_CLI_COMMAND, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(5)  # Wait for connection
    if process.poll() is None:
        print("VPN connected successfully.")
        return True
    print("VPN connection failed.")
    return False

# Configure firewall rules to block unencrypted traffic
def configure_firewall():
    print("Configuring firewall rules...")
    commands = [
        "iptables -F",  # Flush existing rules
        f"iptables -A OUTPUT -o {VPN_INTERFACE} -j ACCEPT",  # Allow VPN traffic
        f"iptables -A OUTPUT -o {NETWORK_INTERFACE} -j DROP"  # Block non-VPN traffic
    ]
    for cmd in commands:
        subprocess.run(cmd, shell=True, check=True)
    print("Firewall rules applied.")

# Monitor session IPs to detect hijacking
def monitor_sessions(log_file="/var/log/apache2/access.log"):
    session_ip_map = {}  # Session ID -> IP
    print("Starting session monitoring...")
    while True:
        with open(log_file, "r") as f:
            for line in f:
                # Example log line: '192.168.1.1 - - [time] "GET /page" 200 - "session=abc123"'
                ip_match = re.search(r"(\d+\.\d+\.\d+\.\d+)", line)
                session_match = re.search(r"session=(\w+)", line)
                if ip_match and session_match:
                    ip, session = ip_match.group(1), session_match.group(1)
                    if session in session_ip_map:
                        if session_ip_map[session] != ip:
                            print(f"Session hijacking detected! Session {session} IP changed from {session_ip_map[session]} to {ip}")
                            # Action: Terminate session (e.g., notify app server)
                    else:
                        session_ip_map[session] = ip
        time.sleep(10)  # Check every 10 seconds

# Rate limiting to mitigate XSS-like abuse
def rate_limit_requests(log_file="/var/log/apache2/access.log", max_requests=100, window=60):
    ip_requests = {}  # IP -> [timestamps]
    print("Starting rate limiting...")
    while True:
        with open(log_file, "r") as f:
            current_time = time.time()
            for line in f:
                ip_match = re.search(r"(\d+\.\d+\.\d+\.\d+)", line)
                if ip_match:
                    ip = ip_match.group(1)
                    if ip not in ip_requests:
                        ip_requests[ip] = []
                    ip_requests[ip].append(current_time)
                    # Clean old requests
                    ip_requests[ip] = [t for t in ip_requests[ip] if current_time - t < window]
                    if len(ip_requests[ip]) > max_requests:
                        print(f"Rate limit exceeded for IP {ip}. Blocking...")
                        subprocess.run(f"iptables -A INPUT -s {ip} -j DROP", shell=True)
        time.sleep(10)

# Main execution
if __name__ == "__main__":
    # Step 1: Connect to VPN
    if connect_vpn():
        # Step 2: Apply firewall rules
        configure_firewall()

        # Step 3: Start adaptive threat monitoring
        session_thread = Thread(target=monitor_sessions)
        rate_limit_thread = Thread(target=rate_limit_requests)
        session_thread.start()
        rate_limit_thread.start()

        # Keep main thread alive
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("Shutting down...")
            subprocess.run("iptables -F", shell=True)  # Clean up firewall rules
            session_thread.join()
            rate_limit_thread.join()
